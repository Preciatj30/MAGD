let i = 0;
var offset = 0;
function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  if (keyIsPressed === false) {
    fill (0)
  }
    else if (i==1){
    fill(0, 375, 0);
    }
    else if (i==2){
    fill(0, 300, 0);
    }
  for (var x = 0; x <= width; x += 45) {
  for (var y = 0; y <= height; y += 65) {
    fill (red(500), 0, red(50));
    ellipse(x, y, 25, 25);
  }
  }
}
function mousePressed() {
  loop();
}

function mouseReleased() {
  noLoop();
}


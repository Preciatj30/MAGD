let a = 200;
let b = 0;
let c = 1
function setup() {
  createCanvas(400, 400);
 stroke(500);
}
function draw() {
  background(100);
  a = b / 1; 
  b = b + 0.2;
  circle(a, 50 , a, width / 100);
  circle(a, height / 2, b, height);
  circle(a, width / 1.2, b, height);
  if (a < width) {
    a = 10;
  }
  if (b > width) {
    b = 0;
  }
  fill('blue')
   let leftWall = 300;
  let rightWall = 50;
  let xc = constrain(mouseX, leftWall, rightWall);
stroke(200)
  line(leftWall, 0, leftWall, height);
  line(rightWall, 0, rightWall, height);
circle(mouseX, 50, mouseX, 100);
  circle(50, mouseY, 100, mouseY);
  circle(mouseX, mouseY, pmouseX, pmouseY);
  let value= 50;
  let m = map(value, 5, 150, 0, width);
  circle(m, 50, 10, 10);
 let x = 4;
  let y = abs(x);
  print(x);
  print(y); 
  print('Bubbles');
}

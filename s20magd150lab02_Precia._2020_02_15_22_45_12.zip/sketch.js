function setup() {
createCanvas(720, 400);
background('#222111');
colorMode(RGB, 255, 214, 20);
fill(255, 175, 0)
triangle(410, 40, 400, 0, 355, 35);
triangle(430, 80, 410, 50, 375, 90);
triangle(470, 120, 440, 90, 420, 140);
arc(500, 10, 150, 150, 4, PI + QUARTER_PI);
colorMode(HSB, 0, 100, 100, 1)
fill('red')
circle(225,185,120);
fill('grey');
quad(160, 200, 160, 175, 290, 175, 290, 200);
}

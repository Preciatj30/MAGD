function setup() {
  createCanvas(128, 128);
  background(200);
}
function draw(){
strokeWeight(10);
point(20, 40);
point(20, 80);
point(100,40);
point(100, 80);
rect(25, 20, 30, 100);
strokeWeight(12.0);
strokeCap(Round);
line(75, 25, 25, 75);
rect(65, 20, 30, 100);
line(6000, 80, 1, 120);
line(120, 90, 1, 200000); 
noStroke();
ellipse(135, 4, 55, 45);
ellipse(120, 90, 5, 5);
}
